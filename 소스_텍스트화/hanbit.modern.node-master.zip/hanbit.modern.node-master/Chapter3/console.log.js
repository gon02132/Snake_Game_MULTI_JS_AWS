console.log('숫자: %d + %d = %d', 273, 52, 273 + 52);
console.log('문자열: %s', 'Hello World .. !', '특수 기호와 상관 없음');
console.log('JSON: %j', { name: 'RintIanTta' });