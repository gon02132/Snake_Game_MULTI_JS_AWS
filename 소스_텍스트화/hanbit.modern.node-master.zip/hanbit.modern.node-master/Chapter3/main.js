﻿// 모듈을 추출합니다.
var mymodule = require('./mymodule.js');

// 모듈을 사용합니다.
console.log('abs(-273) = %d', mymodule.abs(-273));
console.log('circleArea(3) = %d', mymodule.circleArea(3));
